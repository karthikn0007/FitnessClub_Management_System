package exception;

public class TrainerNotAvailableException extends Exception{
	
	public TrainerNotAvailableException(String message) {
        super(message);
    }

}
